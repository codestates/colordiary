import React from 'react'

function RemoveAccount() {
    return (
        <div>
            <h1>RemoveAccout</h1>
        </div>
    )
}

export default RemoveAccount

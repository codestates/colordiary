import React from 'react'

function LogOut() {
    return (
        <div>
            <h1>LogOut</h1>
        </div>
    )
}

export default LogOut

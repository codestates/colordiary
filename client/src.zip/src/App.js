import "./App.css";
import React from "react";
import NavBar from "./components/NavBar/NavBar"

function App() {
  return (
    
    <div>
      <NavBar />
    </div>
  );
}

export default App;
